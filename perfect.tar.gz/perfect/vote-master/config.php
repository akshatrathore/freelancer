<?php

$con= mysqli_connect('localhost','root','tiger','2015cse013') or die  ("Erron in connection");

?>
