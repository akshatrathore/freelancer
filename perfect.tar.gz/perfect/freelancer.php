<!DOCTYPE html>
<html lang="en">
<head>
  <title>Freelancing</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
    </style>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="wregister.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
       <li><a href="mylogin.html"><span class="glyphicon glyphicon-log-in"></span> Login as Freelancer</a></li>  
       <li><a href="c_mylogin.html"><span class="glyphicon glyphicon-log-in"></span> Login as Customer</a></li> 
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>

  
<div class="container">

<br>
<br>
<div class="row">
      
        </div>
              <div class="col-md-12">
          
            <img src="pic1.jpg" alt="Image_work_from_home" class="img-responsive">
          
            <div class="carousel-caption">
              <h1 style="text-align: center;">Get your work done</h1>
              <h1 style="text-align: center;">with our top freelancers</h1>
            </div>
          
        </div>
      
      
 </div>
  
  
<div class="jumbotron">

  <h2 style="text-align: center;">How it works</h2>
      <br>
      <br>
    <div class="row">
      <div class="col-md-4">
        <img src="pic3.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <center><a href="#">FIND</a></center>
        <p style="text-align: center;"><small>Search in the Sector region to know what kind of services we are hosting. We'll quickly match you with the right freelancers.</p>
      </div>

      <div class="col-md-4">
        <img src="pic4.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <h5 style="text-align: center;"><a href="hire.php">HIRE</a></h5>
        <p style="text-align: center;"><small>Browse profiles, reviews, of the freelancer to hire from the top candidates.</p>
      </div>

    
      <div class="col-md-4">
        <img src="pic6.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <h5 style="text-align: center;"><a href="#">PAY</a></h5>
        <p style="text-align: center;"><small>Payments happen on the hourly basis provided by the freelancer.</p>
      </div>
    </div>
</div>

<!--img src="pic2.jpg" alt="Image_work_from_home" class="img-responsive"-->

  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  
</div>





</body>

<footer class="container-fluid text-center">
  
  
</footer>
</html>

