<?php
 session_start();
 session_destroy();
 unset($_SESSION['username']);
 header("Refresh:2; url=freelancer.php");
 echo "<br><br><br><br>  <h2>LOGGING YOU OUT....</h2>";
 ?>
