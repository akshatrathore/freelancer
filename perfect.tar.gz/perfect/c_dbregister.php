<?php
$dbc=mysqli_connect('localhost','root','amulya','final') or die("Error connecting to database");
//if submit is not blanked i.e. it is clicked.
if (isset($_REQUEST['submit'])) // name of the button 
{
// checking the submitted text box for null value by giving there name.
      
        $username=$_POST['username'];
        $name=$_POST['name'];
        $area=$_POST['area'];
        $city=$_POST['city'];
        $phno=$_POST['phno'];
        $email=$_POST['email'];
        $password=$_POST['password'];
	$sql1 = "INSERT INTO clogin (username,password) VALUES ('$username','$password')";
	$sql2 = "INSERT INTO cdetails (username,name,city,area,phno,email) VALUES ('$username','$name','$city','$area',$phno,'$email')";
	
     if(mysqli_query($dbc,$sql1) &&mysqli_query($dbc,$sql2))
  	{
            echo "<br><br><br><br<br><br>CONGRATULATIONS ! YOU ARE A NEW MEMBER TO OUR CUSTOMER COMMUNITY....<br>";
            echo '<a href="c_mylogin.html">Proceed</a>';
        } 
        else 
        {
            die("Error: Try again");
        }
  mysqli_close($dbc);
 
  } 
?>

