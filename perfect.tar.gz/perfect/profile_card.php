
<!DOCTYPE html>
<html lang="en">

<head>

  <title>List of Workers</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    
     .active
     {
      background-color: red;
     }
     body
     {
        background-color: white;/*#D6EBC2;*/
     }    
    .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

.button1 {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}

  </style>

</head>

<body>
<?php
session_start();
$a=$_SESSION['username'];
?>


<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-out"></span>  <?php echo $a;?></a></li>   
       <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>  
     
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>

 <br>
<br>
<br>
<br>



<?php 

$_sector=$_POST['sector'];

$dbc=mysqli_connect('localhost','root','amulya','final');
$query="SELECT * FROM wdetails where sector='$_sector'";
$result=mysqli_query($dbc,$query) or die('Error in the query');
if(mysqli_num_rows($result) == 0) echo "<br><br><h2>No Worker is available under this sector. <br><a href='hire.php'>Explore other sectors?</a></h2>";
while ($row=mysqli_fetch_array($result)) {

?>
<div class="col-sm-3">
<div class="card">
    <div class="btn"><form action="main1.php" method="post">
 <p><button> <img src="pro.png"  style="width:100%">
  <h1><?php
$username=$row["username"];
 print "\n\t<td>$username</h4></td>"; ?></h1>
<input type="hidden" name="hi" value="<?php echo $username; ?>" />
	<h1><?php print"\n\t<td>{$row["name"]}</td>";?></h1>
  <p class="title"><?php print"\n\t<td>{$row["sector"]}</td>\n</tr><br>";?></p>
<p class="title"><?php print"\n\t<td>{$row["area"]}</td>\n</tr><br>";?></p>
<p class="title"><?php print"\n\t<td>{$row["rates"]}</td>\n</tr><br>";?></p>
<p class="title"><?php print"\n\t<td>{$row["phno"]}</td>\n</tr><br>";?></p>
 
 <div class="button1">Contact</div></button></p></form>

</div>
</div>
</div>
<?php 

}
?>
</div>
</div>
</body>
</html>
