<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
 
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
body {
background-color: lightblue;
}
    </style>
</head>
<body>
<?php

session_start();
$hi=$_SESSION['username'];
$name=$_SESSION['name'];

?>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-out"></span>  <?php echo $name;?></a></li>   
       <li><a href="logoutscript.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>  
      
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>


</br>
</br>
</br>
<?php

$n=$_SESSION['name'];

$a=$_SESSION['area'];
$p=$_SESSION['phno'];
$w1=$_SESSION['whour1'];

$w2=$_SESSION['whour2'];

$r=$_SESSION['rates'];



?>
<form action="edited.php" method="POST" name="my_form">
<div class="container">
<div class="card">
<h1>Edit Your Profile</h1>
<div class="row">
<div class="col-sm-6 form-group">
Name:<?php echo $n;?></center>
                <br><label for="username">Name</label>
                <input type="text" placeholder="Edit name..."  name="name" id="name" class="form-control" >
              </div>
<div class="col-sm-6 form-group">
Area:<?php echo $a;?><br>
          
                <label for="area">Area</label>
                <input type="text" placeholder="Edit Area..."  name="area" class="form-control">
              </div>
</div>
<div class="row">
<div class="col-sm-6 form-group">
Contact Number:<?php echo $p;?></center>
                <label for="phone no">Phone Number</label>
                <input type="text" placeholder="Edit Contact no..."  name="phno" class="form-control">
              </div>
<div class="col-sm-6 form-group">
<center>From:<?php echo $w1;?></center>
                <label for="work hour">Work hour(From)</label>
                <input type="text" placeholder="Edit work hour1..."  name="w1" class="form-control">
              </div>
</div>
<div class="col-sm-6 form-group">
To:<?php echo $w2;?>
                <label for="work hour">Work hour(to)</label>
                <input type="text" placeholder="Edit work hour2..."  name="w2" class="form-control">
              </div>
</div>

<div class="col-sm-6 form-group">
Rate per hour:<?php echo $r;?>
                <label for="rate">Rate</label>
                <input type="text" placeholder="Edit rate..."  name="rate" class="form-control">
              </div>
</div>

  <input type="submit" name="submit" value="Save changes"  class="btn btn-lg btn-success btn-block">

</form>
</div>
</div>

</body>
</html>
