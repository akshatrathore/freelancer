<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Worker's Profile</title>
 
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}
/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: #474e5d;
    padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn, .signupbtn {
       width: 100%;
    }
}
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
body {
background-color: lightblue;
}
    </style>

</head>
<body>
<?php
session_start();
$hi=$_SESSION['username'];
?>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
     <li><a href="#"><span class="glyphicon glyphicon-log-out"></span>  <?php echo $hi;?></a></li>   
       <li><a href="logoutscript.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>  
      
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav> 

<div class="container">
<?php
echo "<br><br><br>";

$hello=$_POST['hi'];

$dbc=mysqli_connect('localhost','root','amulya','final');
$query="SELECT * FROM wdetails where username='$hello'";
$result=mysqli_query($dbc,$query) or die('Error in the query');

if(mysqli_num_rows($result) == 0) echo "<br><br><h2>No Worker is available under this sector. <br><a href='hire.php'>Explore other sectors?</a></h2>";
$row=mysqli_fetch_array($result);
$_SESSION['r']=$row['rates'];
?>

</br></br>
<div class="jumbotron">
 <div class="row">
  <div class="col-sm-2">
</br></br>
  <h3> Name :         </h3>
  <h3> Sector : </h3>
 <h3> Place : </h3>
</div>
<div class="col-sm-3">
</br></br>

  <h3> <?php print"\n\t<td>{$row["name"]}</td>";?> </h3>
  <h3> <?php print"\n\t<td>{$row["sector"]}</td>\n</tr><br>";?> </h3>
  <h3> <?php print"\n\t<td>{$row["area"]}</td>\n</tr>";?>,<?php print"\n\t<td>{$row["city"]}</td>\n</tr><br>";?> </h3>
</div>
<div class="col-sm-4">


</div>
  <div class="col-sm-3">

<div class="badge">
<h2 style="text-align:center"><?php print"\n\t<td>{$row["username"]}</td>\n</tr><br>";?></h2>
<img  src="pro.png" alt="John" style="width:100%">
</div>
</div> </div>    
 </div>

<div class="jumbotron">

 <div class="row">
<div class="badge">
  <div class="col-sm-6">
</br></br>
  <h3> Phone No :         </h3>
  <h3>Available Between : </h3>
 <h3> Fees per Hour : </h3>
</div>
<div class="col-sm-6">
</br></br>

  <h3> <?php print"\n\t<td>{$row["phno"]}</td>\n</tr><br>";?> </h3>
  <h3> <?php print"\n\t<td>{$row["whour1"]}</td>\n</tr>";?>-<?php print"\n\t<td>{$row["whour2"]}</td>\n</tr>";?></h3>
  <h3> Rs.<?php print"\n\t<td>{$row["rates"]}</td>\n</tr><br>";?></h3>
</div></div>
<div class="row">
	  
	<div class="col-sm-12">
 <div class="row">
   
    
<div class="col-sm-6">

<button  class="btn-block" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Hire</button>
</br>
<a href="hire.php">Try another one?</a>
 </div> 



</div>   
 </div></div>
</div>
<?php

$query1="SELECT * FROM cdetails where username='$hi'";
$result1=mysqli_query($dbc,$query1) or die('Error in the query');

$r=mysqli_fetch_array($result1) or die('Error querying the database');
$name=$r['name'];
$place=$r['city'];
?>
<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" name="form" method="post" onsubmit="return validateform()" >
    <div class="container">
      <h1>Your Bill</h1>
 
      <hr>
    <h3>Customer's Details</h3>
      
 <label for="email"><b> Name: </b></label>
      <label for="email"><b><?php print"\n\t<td>$name</td>\n<br>";?>  </b></label>

      <label for="psw"><b>Place:</b></label>
      <label for="psw"><b><?php print"\n\t<td>$place</td>\n<br>";?></b></label>
<hr>
   
   <h3>Worker's Details</h3>
      <label for="email"><b> Name: </b></label>
      <label for="email"><b> <?php print"\n\t<td>{$row["name"]}</td>";?>  </b></label>

      <label for="psw"><b>Sector:</b></label>
      <label for="psw"><b> <?php print"\n\t<td>{$row["sector"]}</td>";?></b></label>
<hr>
     
<label for="psw"><b>Booking ID:</b></label>
      <label for="psw"><b>30021234</b></label>
</br>
</br>
</br>

   <label for="psw"><b>Amount to be paid:</b></label>
         <label for="psw"><b>Rs.3000</b></label>
</br>
</br>
</br>
  
      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <a href="freelancer.php"><button type="submit" value="Hire" class="signupbtn">Hire</button></a>
      </div>
    </div>
  </form>
</div>
<div id="id02" >

</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

	}
</script>

</body>
</html>
