<html>
<head><title>Login page</title>

</head>
<body>
<div align="center">
<h3>Login form</h3><br><br><br>
<form action="check.php" method="POST">
Id number:<input type="text" name="id" required="Enter idnumber"><br><br>
Password:<input type="password" name="pass" required="Enter password"><br><br><br>
<input type="submit" value="Submit">
</form>
</div>
