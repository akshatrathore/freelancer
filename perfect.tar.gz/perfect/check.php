<?php
	$dbc=mysqli_connect('localhost','root','amulya','final');
	session_start();

	$username=$_POST['username'];
	$password=$_POST['password'];
	$_SESSION['username']=$_POST['username'];
	

	$sql="SELECT * FROM wlogin where username='$username'" ;
	$result=mysqli_query($dbc,$sql) or die ("Error in Query");
	$row=mysqli_fetch_array($result);
	
	if($password==$row['password'] && $username==$row['username'])
             {
		$_SESSION['name']=$row['name'];
		header("Location:w_login.php");
		}
	
	else
	{
		 header("Refresh:2; url=mylogin.html");
 echo "<br><br><br><br>  <h2>Either username or password is wrong. Try again....</h2>";

	}
?>

