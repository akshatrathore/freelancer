<?php
session_start();
$a=$_SESSION['r'];
$w=$_POST['w3'];
$amount=$a*$w;
echo $amount;
?>
