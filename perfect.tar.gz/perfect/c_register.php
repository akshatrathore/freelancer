<!DOCTYPE html>
<html lang="en">

<head>

  <title>SignUp</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    
     .active
     {
      background-color: red;
     }
     body
     {
        background-color: white;/*#D6EBC2;*/
     }    
    
  </style>
</head>

<body>
<script>
function validateform()
{ 
	var uname =document.forms["myform1"]["username"].value;
	var name = document.forms["myform1"]["name"].value; 
	var city = document.forms["myform1"]["city"].value;
	var area = document.forms["myform1"]["area"].value; 
	var phno = document.forms["myform1"]["phno"].value;
	var email = document.forms["myform1"]["email"].value;
	var password = document.forms["myform1"]["password"].value; 
	var cpassword = document.forms["myform1"]["confirmpassword"].value; 
	

if(uname=="") // username should not be empty
{
alert("username must be filled out");


 document.getElementById("username").focus();
return false;
}

if(name=="") 
{
alert("name must be filled out");


 document.getElementById("name").focus();
return false;
}
 
 if(city=="")
{
alert("city must be filled out");


 document.getElementById("city").focus();
return false;
}

 if(area=="") 
{
alert("area must be filled out");


 document.getElementById("area").focus();
return false;
}

 if(phno=="") 
{
alert("phone number must be filled out");


 document.getElementById("phno").focus();
return false;
}
 var filter=/^\d{10}$/;
 
 if(!filter.test(phno))
       {
     alert("phone number must be numeric and of 10 digits");


 document.getElementById("phno").focus();
document.getElementById("phno").value= '';
 return false;
       }
      
 if(email=="") 
{
alert("email address must be filled out");


 document.getElementById("email").focus();
return false;
}

var atpos=email.indexOf("@");
var dotpos=email.lastIndexOf(".");
 if(atpos<1||dotpos<atpos+2||dotpos+2>=email.length) 
{
alert("Please Enter a valid Email-Address");


 document.getElementById("email").focus();
document.getElementById("email").value= '';
return false;
}
 if(password=="") 
{
alert("password must be filled out");


 document.getElementById("password").focus();
return false;
}

 if(cpassword=="") 
{
alert("Please Re-enter the password");


 document.getElementById("confirmpassword").focus();
return false;
}

if(cpassword!=password) 
{
alert("password doesn't match");


 document.getElementById("password").focus();

document.getElementById("confirmpassword").value= '';

document.getElementById("password").value= '';
return false;
}


}
</script>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="wregister.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
       <li><a href="c_mylogin.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>  
     
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>

 <!-- <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php" style="color:black">Home</a></li>
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="active "><a href="#"><span class="glyphicon glyphicon-user"></span> SignUp</a></li>

        <li ><a href="#myModal" data-toggle="modal" data-target="#myModal" style="color:black"><span class="glyphicon glyphicon-log-in" ></span> Login</a></li>
        <li ><a href="#" style="color:black"><span class="glyphicon glyphicon-menu-hamburger"></span> AboutUs</a></li>  
            

      </ul>
    </div>
  </div>
</nav>-->


<div class="container" style="margin-top:70px">
    <h1 class="well">Registration Form For Customers</h1>
  
  <div class="row">
        <form name ="myform1" onsubmit="return validateform()" action="c_dbregister.php" method="post" role="form">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-sm-6 form-group">
                <label for="username">Username</label>
                <input type="text" placeholder="Enter username..."  name="username" id="username" class="form-control" >
              </div>
              <div class="col-sm-6 form-group">
                <label for="name">Name</label>
                <input type="text" placeholder="Enter Name Here..." name="name" id="name" class="form-control" >
              </div>
            </div>          
            <div class="row">
              <div class="col-sm-6 form-group">
                <label for="user_city">City</label>
                <input type="text" id="city" name="city" placeholder="Enter City Here.." class="form-control" >
              </div>  
              <div class="col-sm-6 form-group">
                <label for="user_state">Area</label>
                <input type="text" id="area" name="area" placeholder="Enter  Area Here..." class="form-control" >
              </div>                
            </div>                       
          <div class="form-group">
            <label for="mobile">Contact Number</label>
            <input type="text" name="phno" id="phno" placeholder="Enter Mobile Number Here.." class="form-control" >
          </div>    
          <div class="form-group">
            <label for="e_id">Email Address</label>
            <input type="text" name="email" id="email" placeholder="Enter Email Address Here.." class="form-control" >
          </div>  

          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Decide your password...." class="form-control" >
          </div>  
<div class="form-group">
            <label for="confirmpassword">Confirm Password</label>
            <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm your password...." class="form-control" >
          </div> 
          <!--<button type="button" class="btn btn-lg btn-info">Submit</button> -->

          <div class="col-xs-6 col-sm-6 col-md-6">
              <input type="submit" name="submit" value="SUBMIT" class="btn btn-lg btn-success btn-block">
          </div>  


          </div>
        </form> 
        </div>
  </div>
</div>

</body>
</html>
