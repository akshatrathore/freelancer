<!DOCTYPE html>
<html lang="en">
<head>
  <title>Freelancing</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
    </style>
</head>
<body>
<?php
session_start();
$_SESSION['username']=$_POST['username'];
$hi=$_SESSION['username'];
?>

<!--div class="modal fade" id="myModal">
  <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title">Log-in</h4>
        </div>
        <form action="login-script.php" method="post" role="form">
              <div class="modal-body">
                <div class="form-group">
              <label for="InputEmail">Email address</label>
              <input class="form-control" name="InputEmail" id="InputEmail" placeholder="Enter email" type="email">
              </div>
            <div class="form-group">
              <label for="InputPassword">Password</label>
            <input class="form-control" id="InputPassword" name="InputPassword" placeholder="Password" type="password">
            </div>
                <p class="text-right"><a href="#">Forgot password?</a></p>
              </div>
              <div class="modal-footer">
                <<a href="#" data-dismiss="modal" class="btn">Close</a>>

                   <div class="col-xs-6 col-sm-6 col-md-6">
                       <input type="submit" name="SUBMIT_MESSAGE" value="LOG-IN" class="btn btn-lg btn-success btn-block">
                  </div>



                <<a href="#" class="btn btn-primary">Log-in</a>>
              </div>
        </form>
      </div>
    </div>
</div-->
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
    <!--div class="collapse navbar-collapse" id="myNavbar"-->
      <!--li class="active"><a href="freelancer.php">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li> 
        </ul>
      </li-->
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-out"></span>  <?php echo $hi;?></a></li>   
      <li><a href="logoutscript.php"><span class="glyphicon glyphicon-log-out"></span> LogOut</a></li>   
      
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>
  
<div class="container">

<br>
<br>
 <?php
$form_username=$_POST['username'];
$form_password=$_POST['password'];

echo "<br>";
$dbc=mysqli_connect('localhost','root','amulya','final')or die('error connecting to mysql server');
$query="select * from clogin where username='$form_username' and password='$form_password'";
$result=mysqli_query($dbc,$query)or die('error querying database');
$row=mysqli_fetch_array($result);
if($form_password==$row['password'])

		{
			
		echo "<br>";
		echo "<h3><b>Username:</h3>".$_SESSION['username'];
}
else
{
echo "<center>Not registered</center>";
echo "<br>";
echo "<br>";
echo '<center><a href="register.php"><button>Signup</button></a></center>';
}
mysqli_close($dbc);
?>

 

 <div class="jumbotron">

  <h2 style="text-align: center;">How it works</h2>
      <br>
      <br>
    <div class="row">
      <div class="col-md-4">
        <img src="pic3.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <center><a href="#">FIND</a></center>
        <p style="text-align: center;"><small>Search in the Sector region to know what kind of services we are hosting. We'll quickly match you with the right freelancers.</p>
      </div>

      <div class="col-md-4">
        <img src="pic4.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <h5 style="text-align: center;"><a href="hire.php">HIRE</a></h5>
        <p style="text-align: center;"><small>Browse profiles, reviews, of the freelancer to hire from the top candidates.</p>
      </div>

    
      <div class="col-md-4">
        <img src="pic6.jpg" alt="Image_work_from_home" style="display: block; margin: 0 auto;" class="img-responsive">
        <h5 style="text-align: center;"><a href="#">PAY</a></h5>
        <p style="text-align: center;"><small>Payments happen on the hourly basis provided by the freelancer.</p>
      </div>
    </div>
</div>

  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  
</div>





</body>

<footer class="container-fluid text-center">

  <p style="text-align: right">For more details contact 1800 1080 2200</p>
</footer>
</html>
