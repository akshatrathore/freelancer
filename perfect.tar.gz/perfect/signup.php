<html>
<head><title>Successful</title></head>
<body>
<?php

      
        $username=$_POST['username'];
        $name=$_POST['name'];
        
        $city=$_POST['city'];
        $area=$_POST['area'];
        $phno=$_POST['phno'];
        $email=$_POST['email'];
        $password=$_POST['password'];
       $sector=$_POST['sector'];
	$whour1=$_POST['whour1'];

$whour2=$_POST['whour2'];


	$rate=$_POST['rate'];
$dbc=mysqli_connect('localhost','root','amulya','final') or die("Error connecting to database");
        $sql1 = "INSERT INTO wlogin (username,password) VALUES ('$username','$password')";
	$sql4 = "INSERT INTO wdetails (username,name,city,area,phno,email,sector,whour1,whour2,rates) VALUES('$username','$name','$city','$area',$phno,'$email','$sector',$whour1,$whour2,$rate)";
	if($result=mysqli_query($dbc,$sql1)&&mysqli_query($dbc,$sql4))
  	{
            echo "<br><br><br><br<br><br>CONGRATULATIONS ! YOU ARE A NEW MEMBER TO OUR FREELANCER COMMUNITY....<br>";
            echo "<a href='mylogin.html'>Proceed</a>";
        } 
        else 
        {
            die("Error: Try again");
        }
  mysqli_close($dbc);

?>
</body>
</html>

