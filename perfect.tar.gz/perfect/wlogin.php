<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
 
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
body {
background-color: lightblue;
}
    </style>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
     
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav> 

<div class="container">
<?php
echo "<br><br><br>";

$hi=$_POST['username'];

$dbc=mysqli_connect('localhost','root','amulya','final');
$query="SELECT * FROM wdetails where username='$hi'";
$result=mysqli_query($dbc,$query) or die('Error in the query');

if(mysqli_num_rows($result) == 0) echo "<br><br><h2>There was something wrong. <br><a href='mylogin.html'>Try again</a></h2>";
$row=mysqli_fetch_array($result)
?>
<form action="edit.php" method="post">
</br></br>
<div class="jumbotron">
 <div class="row">
  <div class="col-sm-2">
</br></br>
  <h3> Name :         </h3>
  <h3> Sector : </h3>
 <h3> Place : </h3>
</div>
<div class="col-sm-3">
</br></br>

  <h3> <?php print"\n\t<td>{$row["name"]}</td>";?> </h3>
<input type="hidden" name="hi" value="<?php echo $username; ?>" />
  <h3> <?php print"\n\t<td>{$row["sector"]}</td>\n</tr><br>";?> </h3>
  <h3> <?php print"\n\t<td>{$row["area"]}</td>\n</tr>";?>,<?php print"\n\t<td>{$row["city"]}</td>\n</tr><br>";?> </h3>
</div>
<div class="col-sm-4">


</div>
  <div class="col-sm-3">

<div class="badge">
<h2 style="text-align:center"><?php print"\n\t<td>{$row["username"]}</td>\n</tr><br>";?></h2>
<img  src="thano2.jpg" alt="John" style="width:100%">
</div>
</div> </div>    
 </div>

<div class="jumbotron">

 <div class="row">
<div class="badge">
  <div class="col-sm-6">
</br></br>
  <h3> Phone No :         </h3>
  <h3>Available Between : </h3>
 <h3> Fees per Hour : </h3>
</div>
<div class="col-sm-6">
</br></br>

  <h3> <?php print"\n\t<td>{$row["phno"]}</td>\n</tr><br>";?> </h3>
  <h3> <?php print"\n\t<td>{$row["whour1"]}</td>\n</tr>";?><?php print"\n\t<td>{$row["ampm1"]}</td>\n</tr>";?>-<?php print"\n\t<td>{$row["whour2"]}</td>\n</tr>";?><?php print"\n\t<td>{$row["ampm2"]}</td>\n</tr><br>";?></h3>
  <h3> Rs.<?php print"\n\t<td>{$row["rates"]}</td>\n</tr><br>";?></h3>
</div></div>
<div class="col-sm-6">

<button  class="btn-block" type="button">EDIT</button>
</br>

 </div> 



</div>   
 </div></div>
</div>


</body>
</html>
