<html>
<body>
Section<input type="number" name="sec">
</body>
</html>



