<!DOCTYPE html>
<html lang="en">

<head>

  <title>SignUp</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    
     .active
     {
      background-color: red;
     }
     body
     {
        background-color: white;/*#D6EBC2;*/
     }    
    
  </style>
<script>
function validateform()
{
 	var uname =document.forms["myform"]["username"].value;
	var name = document.forms["myform"]["name"].value; 
	var city = document.forms["myform"]["city"].value;
	var area = document.forms["myform"]["area"].value; 
	var phno = document.forms["myform"]["phno"].value;
	var email = document.forms["myform"]["email"].value;
	var password = document.forms["myform"]["password"].value; 
	var cpassword = document.forms["myform"]["confirmpassword"].value; 
	var sector = document.forms["myform"]["sector"].value; 
	var whour1 =document.forms["myform"]["whour1"].value;

	var whour2 =document.forms["myform"]["whour2"].value;

	var rate =document.forms["myform"]["rate"].value;



if(uname=="") // username should not be empty
{
alert("username must be filled out");


 document.getElementById("username").focus();
return false;
}

if(name=="") 
{
alert("name must be filled out");


 document.getElementById("name").focus();
return false;
}
 
 if(city=="")
{
alert("city must be filled out");


 document.getElementById("city").focus();
return false;
}

 if(area=="") 
{
alert("area must be filled out");


 document.getElementById("area").focus();
return false;
}

 if(phno=="") 
{
alert("phone number must be filled out");


 document.getElementById("phno").focus();
return false;
}
 var filter=/^\d{10}$/;
 
 if(!filter.test(phno))
       {
     alert("phone number must be numeric and of 10 digits");


 document.getElementById("phno").focus();
document.getElementById("phno").value= '';
 return false;
       }
      
 if(email=="") 
{
alert("email address must be filled out");


 document.getElementById("email").focus();
return false;
}

var atpos=email.indexOf("@");
var dotpos=email.lastIndexOf(".");
 if(atpos<1||dotpos<atpos+2||dotpos+2>=email.length) 
{
alert("Please Enter a valid Email-Address");


 document.getElementById("email").focus();
document.getElementById("email").value= '';
return false;
}
 if(password=="") 
{
alert("password must be filled out");


 document.getElementById("password").focus();
return false;
}

 if(cpassword=="") 
{
alert("Please Re-enter the password");


 document.getElementById("confirmpassword").focus();
return false;
}

if(cpassword!=password) 
{
alert("password doesn't match");


 document.getElementById("password").focus();

document.getElementById("confirmpassword").value= '';

document.getElementById("password").value= '';
return false;
}

if(sector=="")
{
alert("sector must be chosen");

return false;
}

if(whour1=="")
{
alert("Working hour must be chosen");
document.getElementById("whour1").focus();
return false;
}

if(whour2=="")
{
alert("Working hour must be chosen");
document.getElementById("whour2").focus();
return false;
}

if(whour1==whour2 || whour1<0 || whour1>24 || whour2<0 || whour2>24)
{
alert("Select correct work hours");
 document.getElementById("whour1").focus();

document.getElementById("whour1").value= '';

document.getElementById("whour2").value= '';

return false;
}


if(rate=="") 
{
alert("Rate must be filled out");


 document.getElementById("rate").focus();
return false;
}

if(isNaN(rate)) 
{
alert("Please enter Numeric input");


 document.getElementById("rate").focus();

document.getElementById("rate").value= '';
return false;
}
}
</script>
</head>

<body>


<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>

    <ul class="nav navbar-nav navbar-right">
      
        <li><a href="mylogin.html"><span class="glyphicon glyphicon-log-in"></span> Login as Freelancer</a></li>  
       <li><a href="c_mylogin.html"><span class="glyphicon glyphicon-log-in"></span> Login as Customer</a></li>   
     
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>

 

<div class="container" style="margin-top:70px">
    <h1 class="well">Registration Form For Freelancers</h1>
  
  <div class="row">
        <form name ="myform"  action="signup.php" onsubmit="return validateform()" method="post" role="form">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-sm-6 form-group user">
                <label for="username">Username</label>
                <input type="text" placeholder="Enter username..."  name="username" id="username" class="form-control" >
              </div>
              <div class="col-sm-6 form-group">
                <label for="name">Name</label>
                <input type="text" placeholder="Enter Name Here..." name="name" id="name" class="form-control" >
              </div>
            </div>          
            
            <div class="row">
              <div class="col-sm-6 form-group">
                <label for="user_city">City</label>
                <input type="text" id="city" name="city" placeholder="Enter Place Here.." class="form-control" >
              </div>  
              <div class="col-sm-6 form-group">
                <label for="user_area">Area</label>
                <input type="text" id="area" name="area" placeholder="Enter Area Name Here.." class="form-control" >
              </div>  
                
            </div>
                        
            <div class="row">
              <div class="col-sm-6 form-group">
            <label for="mobile">Contact Number</label>
            <input type="text" name="phno" id="phno" placeholder="Enter Mobile Number Here.." class="form-control" >
          </div>    
          <div class="col-sm-6 form-group">
            <label for="e_id">Email Address</label>
            <input type="text" name="email" id="email" placeholder="Enter Email Address Here.." class="form-control" >
          </div>  
</div>

          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Decide your password...." class="form-control" >
          </div>  
	  <div class="form-group">
            <label for="confirmpassword">Confirm Password</label>
            <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm your password...." class="form-control" >
          </div>  
	
          <label> Sectors : </label>
	  <div class="row">
          <div class="radio" >
	   <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Electrician" name="sector" >
            Electrician
            </label>
	  </div>
          </div>
          <div class="radio">
	   <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Carpenter" name="sector">
            Carpenter
            </label>
          </div></div>
          <div class="radio">
             <div class="col-xs-6 col-md-3">
	    <label>
            <input type="radio" value="Cook" name="sector">
            Cook
            </label>
          </div></div>
	  
          <div class="radio">
	  <div class="col-xs-6 col-md-3">            
	  <label>      
	   <input type="radio" value="Gardener" name="sector">
            gardener
            </label>
          </div></div>
          <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Painter" name="sector">
            Painter
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Plumber" name="sector">
            Plumber
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Beauty&Massage" name="sector">
            Beauty&Massage
            </label>
          </div></div>
	  <div class="checkbox">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Driver" name="sector">
            Driver
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Party Planners" name="sector">
            Party Planner
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Pet Caretaker" name="sector">
            Pet Caretaker
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Baby Sitting" name="sector">
            BabySitter
            </label>
          </div></div>
	  <div class="radio">
	  <div class="col-xs-6 col-md-3">
            <label>
            <input type="radio" value="Movers&Packers" name="sector">
            Movers&Packers
            </label>
	  </div></div>
</div>
</br>
<div class="row">
	  
	<div class="col-sm-12">
 <div class="row">
   
     <div class="col-xs-6">
  <div class="dropdown">
	  <label>Work hours : </label>


      
     <input type="number" name="whour1" id="whour1" value="whour1">
  <label>to </label>
       <input type="number" name="whour2" id="whour2" value="whour2">
</br>
 <div class=" alert-info">
    <strong>Note!</strong> Working hours is in 24 Hours format!!
  </div>
   
</div></div> <div class="col-xs-6">
	  
	  <div class="form-group">
            <label for="mobile">How much you want to get paid per hour?(In Rs)</label>
            <input type="text" name="rate" id="rate" placeholder="Rate per hour" class="form-control" >
          </div></div></div></div></div>
          <!--<button type="button" class="btn btn-lg btn-info">Submit</button> -->
</br>
          <div class="col-xs-12">
              <input type="submit" name="submit" value="SUBMIT"  class="btn btn-lg btn-success btn-block">
	      
          </div>  
<a href="c_register.php">Register as a Customer</a>

          </div>
        </form> 
        </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <h6> © 2018 Copyright:Akshat.inc</h6>
  
</footer>

</body>
</html>
