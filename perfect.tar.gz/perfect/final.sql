-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2018 at 11:59 AM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `cdetails`
--

CREATE TABLE `cdetails` (
  `username` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `area` varchar(30) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cdetails`
--

INSERT INTO `cdetails` (`username`, `name`, `city`, `area`, `phno`, `email`) VALUES
('araneedas', 'aranee roy', 'mangolian', 'mongla', 9119119009, 'roy@aranee.com'),
('dggdf', 'dfgf', 'dfgf', '', 1231231231, 'dffd@ggg.com');

-- --------------------------------------------------------

--
-- Table structure for table `clogin`
--

CREATE TABLE `clogin` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clogin`
--

INSERT INTO `clogin` (`username`, `password`) VALUES
('araneedas', '1234'),
('dggdf', '123');

-- --------------------------------------------------------

--
-- Table structure for table `wdetails`
--

CREATE TABLE `wdetails` (
  `username` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `area` varchar(30) NOT NULL,
  `phno` bigint(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sector` varchar(40) NOT NULL,
  `whour1` int(20) NOT NULL,
  `whour2` int(20) NOT NULL,
  `rates` int(20) NOT NULL,
  `available` binary(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wdetails`
--

INSERT INTO `wdetails` (`username`, `name`, `city`, `area`, `phno`, `email`, `sector`, `whour1`, `whour2`, `rates`, `available`) VALUES
('akshat', 'Akshat Rathore', 'a', 'MS Dhoni', 1234123455, 'a', 'Electrician', 8, 11, 200, NULL),
('amulya', 'amulyars', 'blore', 'ynk', 9023459876, 'a@gmail.com', 'Painter', 9, 17, 500, NULL),
('hello', 'hello', 'salkanpur', 'purpur', 1020304050, 'qwe@gmail.com', 'Carpenter', 3, 12, 5000, NULL),
('t', 't', 't', 't', 5, 'g', 'Pet Caretaker', 1, 1, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wlogin`
--

CREATE TABLE `wlogin` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wlogin`
--

INSERT INTO `wlogin` (`username`, `password`) VALUES
('', ''),
('a', 's'),
('akak', '1234'),
('Akshaat', '1'),
('akshat', '1234'),
('amulya', '1234'),
('d', 'd'),
('g', 'h'),
('hawk', '11'),
('hawkq', '111'),
('Hawkye', '1234'),
('hello', '22'),
('ross', '1234'),
('s', 'h'),
('saaas', '1'),
('saaasas', '1234'),
('shtjrf', '1234'),
('t', 't');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cdetails`
--
ALTER TABLE `cdetails`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `clogin`
--
ALTER TABLE `clogin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `wdetails`
--
ALTER TABLE `wdetails`
  ADD PRIMARY KEY (`username`),
  ADD KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `username_3` (`username`),
  ADD KEY `username_4` (`username`);

--
-- Indexes for table `wlogin`
--
ALTER TABLE `wlogin`
  ADD PRIMARY KEY (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
