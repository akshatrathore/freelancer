<!DOCTYPE html>
<html lang="en">
<head>
  <title>Hire</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .jumbotron 
        {
      margin-bottom: 30px;
      margin-top: 60px;
      color:grey;      
        }
    </style>
</head>
<body style="background-color: black;">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="freelancer.php">Freelancing</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
 
      <li><a href="#"><span class="glyphicon glyphicon-search"></span> Search</a></li>     
    </ul>
<?php
session_start();
$a=$_SESSION['username'];
?>
    <ul class="nav navbar-nav navbar-right">
	<li><a href="#"><span class="glyphicon glyphicon-log-out"></span>  <?php echo $a;?></a></li>   
       <li><a href="logoutscript.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>  
      <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>       
    </ul>
    </div>
  </div>
</nav>
	

<div class="jumbotron">
  <h1 style="text-align: center;">Sectors</h1>
  <!--p>...</p>
  <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a></p-->
  <div class="row">
  <div class="col-xs-6 col-md-3">
<form method="post" action="profile_card.php">
    
      <input type="image" name="Electrician" src="electrician.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Electrician">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Carpenter" src="carpenter.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Carpenter">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <form method="post" action="profile_card.php">
      <input type="image" name="Cook" src="cook.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Cook"></form>
      <div class="carousel-caption">
         
            </div>
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <form method="post" action="profile_card.php">
      <input type="image" name="Gardener" src="gardener.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Gardener">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

 <div class="col-xs-6 col-md-3">
  <form method="post" action="profile_card.php">
      <input type="image" name="Painter" src="painter.png" alt="..." style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Painter">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

 <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Plumber" src="plumber.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Plumber">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>


 <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Beauty" src="beauty.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Beauty & Massage">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

 <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Driver" src="driver.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Driver">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

 <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Party" src="party.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Party Planners">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

 <div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Pet Caretaker" src="pet.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Pet Caretaker">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>

  <div class="col-xs-6 col-md-3">
    <form method="post" action="profile_card.php">
      <input type="image" name="Baby Sitter" src="baby.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Baby Sitter">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6></form>
            </div>
    </a>
  </div>
 
<div class="col-xs-6 col-md-3">
   <form method="post" action="profile_card.php">
      <input type="image" name="Movers and Packers" src="movers.png" alt="submit" style="width:250px;height:160px;">
<input type="hidden" name="sector" value="Movers and Packers">
      <div class="carousel-caption">
              <h6 style="text-align: center;"></h6>
</form>
            </div>
    </a>
  </div>

</div>
</div>
</body>

<footer class="container-fluid text-center">
 
  
  <p style="text-align: right">For more details contact 1800 1080 2200</p>
</footer>
</html>
