<html>
<head><title>Done with the changes</title></head>
<body>
<?php
session_start();
$form_username=$_SESSION['username'];
echo $form_username;
$form_name=$_POST['name'];
echo "<br>Name:<br>".$form_name;
$form_area=$_POST['area'];
echo "<br>Area:<br>".$form_area;

$form_phno=$_POST['phno'];
echo "<br>Phone No:<br>".$form_phno;
$form_w1=$_POST['w1'];
echo "<br>From(Work hour1):<br>".$form_w1;
$form_aa=$_POST['aa'];
echo "<br>AM/PM:<br>".$form_aa;
$form_w2=$_POST['w2'];
echo "<br>To(Work hour2):<br>".$form_w2;
$form_pp=$_POST['pp'];
echo "<br>AM/PM:<br>".$form_pp;
$form_rate=$_POST['rate'];
echo "<br>Rate:<br>".$form_rate;

$dbc=mysqli_connect('localhost','root','amulya','final')or die('Error Not able to connect to the database');
$sql="update wdetails set name='$form_name',area='$form_area',phno=$form_phno,whour1=$form_w1 where username='$form_username'";
$res=mysqli_query($dbc,$sql) or die('error querying the database');

if($res){
echo "It has been updated successfully. Please make sure that you login with this updated Username henceforth! Thank You";
header("Location:w_login.php");
echo "<br>";}
else
{

echo "Problem updating your details. Please check your details and try again.";
header("Refresh:2; url=mylogin.html");
}
mysqli_close($dbc);
?>
<br>
<center><a href="logout.php"><button class="btn success">Logout</button></a></center></center><br>
</body>
</html>

