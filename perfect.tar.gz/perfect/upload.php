<html>
<head>
<style>
body{background-color:lightpink;}</style>
<title>Login</title>
</head>
<body>
<?php
$image_tempname=$_FIlES['fileToUpload']['name'];
echo "<h1><center>Welcome</center></h1>";
echo "<br>";
$dbc=mysqli_connect('localhost','root','amulya','sample')or die('error connecting to mysql server');
$imageDir="/var/www/html/images";
$imagename=$imageDir.$image_tempname;

mysqli_close($dbc);
?>
</body>
</html>
